﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.Womens = context.Leagues.Where(l => l.Name.Contains("Womens"));
            ViewBag.Hockey = context.Leagues.Where(l => l.Sport.Contains("Hockey"));
            ViewBag.NotFootball = context.Leagues.Where(l => !l.Sport.Contains("Football"));
            ViewBag.Conferences = context.Leagues.Where(l => l.Name.Contains("conferences"));
            ViewBag.Atlantic = context.Leagues.Where(l => l.Name.Contains("Atlantic"));
            ViewBag.Dallas = context.Teams.Where(t => t.Location.Contains("Dallas"));
            ViewBag.Raptors = context.Teams.Where(t => t.TeamName.Contains("Raptors"));
            ViewBag.City = context.Teams.Where(t => t.Location.Contains("City"));
            ViewBag.TName = context.Teams.Where(t => t.TeamName[0] == 'T');
            ViewBag.OrderedTeamsLocation = context.Teams.OrderBy(t => t.Location);
            ViewBag.ReversedTeams = context.Teams.OrderByDescending(t => t.TeamName);
            ViewBag.Cooper = context.Players.Where(p => p.LastName.Contains("Cooper"));
            ViewBag.Joshua = context.Players.Where(p => p.FirstName.Contains("Joshua"));
            ViewBag.CooperNotJoshua = context.Players.Where(p => p.LastName.Contains("Cooper") && !p.FirstName.Contains("Joshua"));
            ViewBag.AlexanderOrWyatt = context.Players.Where(p => p.FirstName.Contains("Alexander") || p.FirstName.Contains("Wyatt"));


            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            ViewBag.AtlanticTeams = context.Teams.Where(t => t.CurrLeague.Name.Contains("Atlantic Soccer Conference"));
            ViewBag.CurrPlayersPenguins = context.Players.Where(p => p.CurrentTeam.TeamName.Contains("Penguin") && p.CurrentTeam.Location.Contains("Boston"));
            ViewBag.CollegiateBaseballTeams = context.Teams.Where(t => t.CurrLeague.Name.Contains("International Collegiate Baseball Conference"));
            ViewBag.AmateurFootballTeams = context.Teams.Where(t => t.CurrLeague.Name.Contains("American Conference of Amateur Football"));
            ViewBag.FootballTeams = context.Teams.Where(t => t.CurrLeague.Sport.Contains("Football"));
            ViewBag.SophiaTeam = context.Teams
                .Include(p => p.CurrentPlayers)
                .Where(t => t.CurrentPlayers.All(p => p.FirstName.Contains("Sophia")));
            ViewBag.FloresNotRaptors = context.Players
                .Include(p => p.CurrentTeam)
                .Where(p => p.LastName.Contains("Flores") && p.CurrentTeam.TeamName.Contains("Raptors"));
            ViewBag.CurrTigerPlayer = context.Players
                .Include(p => p.CurrentTeam)
                .Where(p => p.CurrentTeam.TeamName.Contains("Tiger-Cats") && p.CurrentTeam.Location.Contains("Manitoba"));
            ViewBag.MoreThanTwelve = context.Teams
                .Include(t => t.AllPlayers)
                .Where(t => t.AllPlayers.Count > 12);

            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}