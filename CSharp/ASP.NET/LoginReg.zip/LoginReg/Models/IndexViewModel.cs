namespace LoginReg.Models
{
    public class IndexViewModel
    {
        public LogUser LogUser { get; set; }
        public RegUser RegUser { get; set; }
    }
}