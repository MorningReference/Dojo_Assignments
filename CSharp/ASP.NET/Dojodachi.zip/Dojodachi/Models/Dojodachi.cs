namespace Dojodachi
{
    public class Dojodachi
    {
        public string Name { get; set; }
        public int Happiness { get; set; }
        public int Fullness { get; set; }
        public int Energy { get; set; }
        public int Meal { get; set; }
        public string Message { get; set; }
        public string Image { get; set; }
    }
}