namespace DojoSurvey.Models
{
    public class Survey
    {
        public string Name { get; set; }
        public string Location { get; set; }
        public string FavLang { get; set; }
        public string Comment { get; set; }
    }
}