import React from 'react';

export default function Home() {
    return <h1>Welcome</h1>;
}
