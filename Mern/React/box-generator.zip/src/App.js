import React from 'react';
import logo from './logo.svg';
import './App.css';
import BoxGenerator from './components/BoxGenerator';

function App() {
    return <BoxGenerator />;
}

export default App;
