import React from 'react';
import logo from './logo.svg';
import './App.css';
import Pokemon from './components/Pokemon';

function App() {
    return <Pokemon />;
}

export default App;
