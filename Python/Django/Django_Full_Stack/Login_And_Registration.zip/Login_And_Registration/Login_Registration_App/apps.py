from django.apps import AppConfig


class LoginRegistrationAppConfig(AppConfig):
    name = 'Login_Registration_App'
