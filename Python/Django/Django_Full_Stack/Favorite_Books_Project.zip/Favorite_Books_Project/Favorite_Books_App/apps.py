from django.apps import AppConfig


class FavoriteBooksAppConfig(AppConfig):
    name = 'Favorite_Books_App'
