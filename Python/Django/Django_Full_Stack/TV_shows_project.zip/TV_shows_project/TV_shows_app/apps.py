from django.apps import AppConfig


class TvShowsAppConfig(AppConfig):
    name = 'TV_shows_app'
