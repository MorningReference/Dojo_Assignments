from django.apps import AppConfig


class FirstAppConfig(AppConfig):
    name = 'First_App'
