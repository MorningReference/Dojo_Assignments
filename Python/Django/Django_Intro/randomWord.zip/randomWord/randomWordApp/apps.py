from django.apps import AppConfig


class RandomwordappConfig(AppConfig):
    name = 'randomWordApp'
