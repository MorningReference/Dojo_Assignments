from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		# "leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"baseballLeagues": League.objects.filter(sport="Baseball"),
		"womensLeagues": League.objects.filter(name__contains="Womens'"),
		"hockeyLeagues": League.objects.filter(sport__contains="Hockey"),
		"notFootballLeagues": League.objects.exclude(sport__contains="Football"),
		"conferenceLeagues": League.objects.filter(name__icontains="conference"),
		"atlanticLeagues": League.objects.filter(name__contains="Atlantic"),
		"dallasTeams": Team.objects.filter(location="Dallas"),
		"raptorTeams": Team.objects.filter(team_name__icontains="Raptors"),
		"cityTeams": Team.objects.filter(location__icontains="City"),
		"tBeginsTeams": Team.objects.filter(team_name__startswith="T"),
		"alphabeticalTeams": Team.objects.order_by("location"),
		"reverseAlphaTeams": Team.objects.order_by("-team_name"),
		"cooperPlayers": Player.objects.filter(last_name="Cooper"),
		"joshuaPlayers": Player.objects.filter(first_name="Joshua"),
		"cooperNotJoshuaPlayers": Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua"),
		"alexOrWyattPlayers": Player.objects.order_by('first_name').filter(first_name="Alexander") | Player.objects.order_by('first_name').filter(first_name="Wyatt")
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")