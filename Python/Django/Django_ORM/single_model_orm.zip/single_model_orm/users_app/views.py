from django.shortcuts import render, redirect
from .models import users

def index(request):
    context = {
        "all_the_users": users.objects.all()
    }
    return render(request, 'index.html', context)

def addUser(request):
    first_name_from_form = request.POST['first_name']
    last_name_from_form = request.POST['last_name']
    email_from_form = request.POST['email']
    age_from_form = request.POST['age']
    users.objects.create(first_name=first_name_from_form, last_name=last_name_from_form, email_address=email_from_form, age=age_from_form)
    return redirect('/')